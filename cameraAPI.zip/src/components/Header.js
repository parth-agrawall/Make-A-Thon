import React from "react";

function Header() {
  return (
    <div className="hh">
      <header>
        <nav>
          <ul>
            <li>
              {" "}
              <a href="#">Home</a>{" "}
            </li>
            <li>
              {" "}
              <a href="#">About Us</a>{" "}
            </li>
            <li>
              {" "}
              <a href="#">Services</a>{" "}
            </li>
            <li>
              {" "}
              <a href="#">Help</a>{" "}
            </li>
          </ul>
          <button type="button" name="login">
            login
          </button>
        </nav>
      </header>
    </div>
  );
}

export default Header;
